import React from "react";

class NotFoundPage extends React.Component{
    render() {
        return (
            <div className="notes-app">
                <h1>404</h1>
                <h2>Oops! Halaman yang anda cari tidak tersedia.</h2>
            </div>
        );
    }
}

export default NotFoundPage;