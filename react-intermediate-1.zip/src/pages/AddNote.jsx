/* eslint-disable no-unused-vars */
import React from "react";
import { addNote } from "../utils/data";
import NoteInput from "../components/NoteInput";

function AddNote() {
    function onAddNoteHandler(note) {
        addNote(note)
    }

    return (
        <section>
            <h2>Add Note</h2>
            <NoteInput addNote={onAddNoteHandler} />
        </section>
    )
}

export default AddNote;