import React from "react";
import NoteList from "../components/NoteList";
import { deleteNote, getArchivedNotes, unarchiveNote } from "../utils/data";

class ArchivedNotes extends React.Component{
    constructor(props) {
        super(props);
        this.state = {
            notes: getArchivedNotes(),
        }
        this.onDeleteHandler = this.onDeleteHandler.bind(this);
        this.onStatusChangeHandler = this.onStatusChangeHandler.bind(this);
    }

    onDeleteHandler(id) {
        deleteNote(id);

        this.setState(() => {
            return {
                notes: getArchivedNotes(),
            }
        })
    }

    onStatusChangeHandler(id) {
        unarchiveNote(id);

        this.setState(() => {
            return {
                notes: getArchivedNotes(),
            }
        })
    }

    render() {
        return (
            <div className="notes-app">
                <h2>Archived Note List</h2>
                <NoteList notes={this.state.notes} onDelete={this.onDeleteHandler} onStatusChange={this.onStatusChangeHandler}/>
            </div>
        );
    }
}

export default ArchivedNotes;