/* eslint-disable no-unused-vars */
import React from "react";

function Footer() {
    return (
        <nav className="footer" >
            <p className="footer-text" >Project 1 Kelas Belajar Fundamental Aplikasi Web dengan React - IDCamp 2024</p>
            <p className="footer-text" >Hagi Azzam Azzikri - 2025</p>
        </nav>
    );
}

export default Footer;