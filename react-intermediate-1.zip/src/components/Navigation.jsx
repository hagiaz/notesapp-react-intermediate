/* eslint-disable no-unused-vars */
import React from 'react';
import { Link } from 'react-router-dom';
 
function Navigation() {
  return (
    <nav className="navbar">
      <ul className='navbar-links'>
        <li className='tagline'>Your Personal Notes Web App</li>
      </ul>
      <ul className='navbar-links'>
        <li><Link to="/">Home</Link></li>
        <li><Link to="/add">Add Note</Link></li>
        <li><Link to="/archived">Archived</Link></li>
      </ul>
    </nav>
  );
}
 
export default Navigation;