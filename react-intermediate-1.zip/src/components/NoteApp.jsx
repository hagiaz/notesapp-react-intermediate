/* eslint-disable no-unused-vars */
import React from "react";
import { Route, Routes } from "react-router-dom";
import Navigation from "./Navigation";
import HomePage from "../pages/HomePage";
import AddNote from "../pages/AddNote";
import ArchivedNotes from "../pages/ArchivedNotes";
import DetailPage from "../pages/DetailPage";
import NotFoundPage from "../pages/NotFoundPage";

function NoteApp() {
    return (
        <div className="notes-app">
            <header>
                <Navigation />
                <h1 className="app-name">NotesApp</h1>
            </header>
            <main>
                <Routes>
                    <Route path="/" element={<HomePage />} />
                    <Route path="/add" element={<AddNote />} />
                    <Route path="/archived" element={<ArchivedNotes />} />
                    <Route path="/detail/:id" element={<DetailPage />} />
                    <Route path="/*" element={<NotFoundPage />} />
                </Routes>
            </main>
        </div>
    );
}

export default NoteApp;